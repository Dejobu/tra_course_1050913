package org.zkoss.training.modularize;

public interface CallBack {

	public void notify(Object data);
}
