package org.zkoss.training.component;

public class TextboxVM {

	private String value = "initial value";

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
}
